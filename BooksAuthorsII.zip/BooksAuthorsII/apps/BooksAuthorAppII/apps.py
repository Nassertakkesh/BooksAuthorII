from django.apps import AppConfig


class BooksauthorappiiConfig(AppConfig):
    name = 'BooksAuthorAppII'
